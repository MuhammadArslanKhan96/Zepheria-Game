import teamwar from './teamwar';

export default {
    teamwar
};
