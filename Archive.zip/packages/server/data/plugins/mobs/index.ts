import ant from './ant';
import forestdragon from './forestdragon';
import ogrelord from './ogrelord';
import queenant from './queenant';
import santa from './santa';
import skeletonking from './skeletonking';
import piratecaptain from './piratecaptain';
import spider from './spider';
import hellhound from './hellhound';

export default {
    ogrelord,
    skeletonking,
    queenant,
    ant,
    forestdragon,
    santa,
    piratecaptain,
    spider,
    hellhound
};
