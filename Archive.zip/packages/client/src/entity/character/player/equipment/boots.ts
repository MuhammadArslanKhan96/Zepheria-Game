import Equipment from './equipment';

export default class Boots extends Equipment {}
