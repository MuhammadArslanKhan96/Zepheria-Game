import Equipment from './equipment';

export default class Weapon extends Equipment {}
