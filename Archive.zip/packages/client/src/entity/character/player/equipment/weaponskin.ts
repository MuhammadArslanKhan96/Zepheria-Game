import Equipment from './equipment';

export default class WeaponSkin extends Equipment {}
