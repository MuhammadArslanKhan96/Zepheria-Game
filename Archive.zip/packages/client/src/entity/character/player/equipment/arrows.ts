import Equipment from './equipment';

export default class Arrows extends Equipment {}
