import Equipment from './equipment';

export default class Pendant extends Equipment {}
