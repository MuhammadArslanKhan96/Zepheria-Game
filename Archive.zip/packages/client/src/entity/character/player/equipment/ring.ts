import Equipment from './equipment';

export default class Ring extends Equipment {}
