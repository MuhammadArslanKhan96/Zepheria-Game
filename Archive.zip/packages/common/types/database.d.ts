export type DatabaseTypes = 'mongo' | 'mongodb';
