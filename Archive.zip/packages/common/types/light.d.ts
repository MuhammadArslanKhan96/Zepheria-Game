export interface SerializedLight {
    x: number;
    y: number;
    colour: string;
    diffuse: number;
    distance: number;
}
