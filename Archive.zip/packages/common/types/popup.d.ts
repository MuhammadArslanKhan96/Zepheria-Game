export interface PopupData {
    title: string;
    text: string;
    colour: string;
}
