export interface NPCData {
    name?: string;
    text?: string[];
    role?: string;
    store?: string;
}
