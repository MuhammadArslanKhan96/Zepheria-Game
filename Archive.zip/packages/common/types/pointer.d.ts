export interface PointerData {
    type: number;
    x?: number;
    y?: number;
    instance?: string;
    button?: string;
}
