export type Status = 'lobby' | 'ingame' | 'exit';

export enum Team {
    Red,
    Blue
}
