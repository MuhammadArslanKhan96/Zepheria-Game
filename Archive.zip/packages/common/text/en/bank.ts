export default {
    NOT_ENOUGH_SPACE: 'You do not have enough space in your bank.'
};
